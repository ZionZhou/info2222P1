import string
import random
from Crypto.Hash import MD5



def password_calculator(password,salt):
    hashed = MD5.new((password + salt).encode()).hexdigest()
    return hashed

def hash_calculator(message):
    hashed = MD5.new((message).encode()).hexdigest()
    return hashed



def salt_generator():
    acsii_set = list(string.ascii_lowercase + string.ascii_uppercase + string.digits)
    acsii_set_length = len(acsii_set)
    res=[]
    for i in range(128):
        res.append(acsii_set[random.randint(0,acsii_set_length-1)])

    salt = ''.join(res)
    return salt